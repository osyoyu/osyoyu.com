# 実世界指向システム 課題
201411432 有友 大輔

## 実行
比較的新しい Node.js 環境がある環境下で実行できます。

```
$ npm install
$ npm run dev-server
```

を実行したあと、 [http://localhost:8080](http://localhost:8080) にアクセスすることで確認できます。


## ソースコード
`/src` 以下に主な JavaScript ファイルがあります。

`/src/System.jsx`: アームの姿勢のコントロールや、自由度の追加などに関するコード
`/src/components/drawzone` 以下: 画面上部のアームのレンダリングに関するコード
`/src/components/console` 以下: 画面下部のコントロールに関するコード
