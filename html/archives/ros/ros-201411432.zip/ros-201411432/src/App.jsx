import React, { Component } from 'react';

import styled from 'styled-components';
import { Flex, Box } from 'grid-styled';
import { Button } from '@blueprintjs/core';

import Navbar from './components/Navbar';
import System from './components/System';

const Title = styled.h1`
  font-size: 2em;
`;

export default class App extends Component {
  render() {
    return (
      <div className="app">
        <Navbar />
        <div className="content">
          <System />
        </div>
      </div>
    );
  }
}
