import React, { Component } from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { Flex, Box } from 'grid-styled';
import { Slider } from '@blueprintjs/core';

const ArmConsoleBox = styled.div`
  background: #dce9f5;
  margin: 5px;
  padding: 15px;
`;

export default class ArmConsole extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return(
      <ArmConsoleBox>
        <h2>{this.props.arm.name}</h2>
        <h3>長さ</h3>
        <Slider
          min={0}
          max={300}
          stepSize={10}
          labelStepSize={30}
          onChange={this.props.handleArmLengthChange(this.props.slug)}
          value={this.props.arm.length}
        />
        <h3>角度</h3>
        <Slider
          min={0}
          max={360}
          stepSize={1}
          labelStepSize={60}
          onChange={this.props.handleArmAngleChange(this.props.slug)}
          value={this.props.arm.angle}
        />
      </ArmConsoleBox>
    )
  }
}
