import React, { Component } from 'react';

import styled from 'styled-components';
import { Flex, Box } from 'grid-styled';
import { Button, Slider } from '@blueprintjs/core';

import ArmConsole from './ArmConsole';

/**
 * 各アームの長さ・角度を制御するコンソール
 */
const ConsoleBox = styled.div`
  padding: 10px;
`;

export default class Console extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <ConsoleBox>
        <Flex wrap='wrap'>
          {Object.keys(this.props.arms).sort().map((key) => {
            return (
              <Box width={1/2} key={key}>
                <ArmConsole slug={key} arm={this.props.arms[key]} handleArmLengthChange={this.props.handleArmLengthChange} handleArmAngleChange={this.props.handleArmAngleChange} />
              </Box>
            )
          })}
        </Flex>
        <Button onClick={this.props.handleAddArm}>自由度を追加</Button>
      </ConsoleBox>
    )
  }
}
