import React, { Component } from 'react';

import { Breadcrumb } from '@blueprintjs/core';

export default class Navbar extends Component {
  render() {
    return (
      <nav className="pt-navbar pt-fixed-top">
        <div className="pt-navbar-group pt-align-left">
          <ul className="pt-breadcrumbs">
            <li>
              <Breadcrumb text="実世界指向システム 課題 201411432 有友 大輔" />
            </li>
          </ul>
        </div>
      </nav>
    );
  }
}
