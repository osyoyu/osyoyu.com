import React from 'react';

import styled from 'styled-components';

const ArmBox = styled.div`
  position: absolute;
  width: ${props => (props.values.length)}px;
  height: 5px;

  left: ${props => props.startCoords.x}px;
  top: ${props => props.startCoords.y}px;

  background: #000000;

  transform: rotate(${props => props.angle}deg);
  transform-origin: 0% 50% 0;
`;

export default class Arm extends React.Component {
  render() {
    return (
      <ArmBox values={this.props.values} startCoords={this.props.startCoords} endCoords={this.props.endCoords} angle={this.props.angle} />
    );
  }
}
