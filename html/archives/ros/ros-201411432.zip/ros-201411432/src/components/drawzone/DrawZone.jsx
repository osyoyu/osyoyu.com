import React, { Component } from 'react';

import styled from 'styled-components';

import Arm from './Arm';

const DrawZoneBox = styled.div`
  position: relative;
  height: 30rem;
  background: pink;
  margin: 5px;
  padding: 10px;
`;

function deg2rad(deg) {
  return deg / 180 * Math.PI;
}
function rad2deg(rad) {
  return rad / Math.PI * 180;
}

// アームの座標系の原点, アームの長さ, アームの角度からアームの終点座標を計算
function calculateEndCoords(startCoords, length, angleDeg) {
  return {
    x: startCoords.x + length * Math.cos(deg2rad(angleDeg)),
    y: startCoords.y + length * Math.sin(deg2rad(angleDeg)),
  }
}

/**
 * アームのレンダリングエリア
 */
export default class DrawZone extends Component {
  render() {
    const arms = this.props.arms;
    const keys = Object.keys(arms).sort();

    // 各アームの座標系の原点
    let coordSysOrigins = [
      {x: 0, y: 0}, // アーム1の原点座標は World 座標系の (0, 0)
    ];
    let currentAngle = 0;

    return (
      <DrawZoneBox>
        {keys.map((key, i) => {
          // アームの長さ・角度をアーム情報から取得
          const length = arms[key].length;
          currentAngle += arms[key].angle;
          // アームの始点座標を取得 (アーム座標系の原点)
          const startCoords = coordSysOrigins[i];
          // アームの終点座標を取得
          const endCoords = calculateEndCoords(startCoords, length, currentAngle);
          // アームの終点座標を次のアームの原点座標として保存
          coordSysOrigins.push(endCoords);

          // アームをレンダリング
          return (
            <Arm key={arms[key].name} values={arms[key]} startCoords={startCoords} endCoords={endCoords} angle={currentAngle} />
          )
        })}
      </DrawZoneBox>
    )
  }
}
