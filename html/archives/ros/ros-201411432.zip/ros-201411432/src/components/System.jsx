import React from 'react';

import styled from 'styled-components';
import { Flex, Box } from 'grid-styled';
import { Button } from '@blueprintjs/core';

import Navbar from './Navbar';
import DrawZone from './drawzone/DrawZone';
import Console from './console/Console';

const SystemBox = styled.div`
`;

export default class System extends React.Component {
  constructor(props) {
    super(props);

    // アームを格納する state
    this.state = {
      arm1: {
        name: 'アーム1',
        length: 300,
        angle: 0,
      },
      arm2: {
        name: 'アーム2',
        length: 200,
        angle: 90,
      },
      arm3: {
        name: 'アーム3',
        length: 200,
        angle: 300,
      },
    }

    this.addArm = this.addArm.bind(this);
    this.handleArmAngleChange = this.handleArmAngleChange.bind(this);
    this.handleArmLengthChange = this.handleArmLengthChange.bind(this);
  }

  // 自由度の追加処理
  addArm() {
    let arms = Object.assign({}, this.state);
    const armNumber = (Object.keys(arms).length + 1).toString();
    arms["arm" + armNumber] = {
      name: `アーム${armNumber}`,
      length: 200,
      angle: 0,
    }
    this.setState(arms);
  }

  handleArmAngleChange(armName) {
    return (angle) => {
      let arms = Object.assign({}, this.state);
      arms[armName].angle = angle;
      this.setState(arms);
    }
  }

  handleArmLengthChange(armName) {
    return (length) => {
      let arms = Object.assign({}, this.state);
      arms[armName].length = length;
      this.setState(arms);
    }
  }

  render() {
    return (
      <SystemBox>
        <DrawZone arms={this.state} />
        <Console arms={this.state} handleArmLengthChange={this.handleArmLengthChange} handleArmAngleChange={this.handleArmAngleChange} handleAddArm={this.addArm} />
      </SystemBox>
    )
  }
}
